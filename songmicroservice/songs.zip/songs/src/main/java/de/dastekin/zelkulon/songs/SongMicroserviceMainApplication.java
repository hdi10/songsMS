package de.dastekin.zelkulon.songs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SongMicroserviceMainApplication {

	public static void main(String[] args) {
		SpringApplication.run(SongMicroserviceMainApplication.class, args);
	}

}
