package de.dastekin.zelkulon.zelkulon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZelkulonMicroserviceMainApplicationTests {

	@Test
	void contextLoads() {
	}

}
