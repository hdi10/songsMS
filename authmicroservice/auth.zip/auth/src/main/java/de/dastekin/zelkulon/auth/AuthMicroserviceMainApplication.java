package de.dastekin.zelkulon.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthMicroserviceMainApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthMicroserviceMainApplication.class, args);
	}

}
