package de.dastekin.zelkulon.zelkulon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZelkulonMicroserviceMainApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZelkulonMicroserviceMainApplication.class, args);
	}

}
